  
"""
Plotting data from the SARS database
====================================
"""

import sharppy.sharptab as tab
import sharppy.databases.sars as sars
import numpy as np
import os
import matplotlib.pyplot as plt
print("hello")
